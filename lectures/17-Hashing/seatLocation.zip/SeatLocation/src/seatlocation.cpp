#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
using namespace std;

int alphaIndex(char ch) {
    return ch - 'a';
}

int getSeatArea(string name) {
    int name0 = alphaIndex(name[0]);
    int name1 = alphaIndex(name[1]);
    return (name0 + 7 * name1) % 10;
}

void nameQuery() {
    string name = getLine("Enter your first name: ");
    name = toLowerCase(name);
    int seatArea = getSeatArea(name);
    cout << "Seat location for " << name << " is: " << seatArea << endl;
    cout << endl;
}

int main() {
    cout << "Hello, World!" << endl;
    while(true) {
        nameQuery();
    }
    return 0;
}
