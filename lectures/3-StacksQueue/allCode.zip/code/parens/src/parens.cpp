/**
 * CS106B Chris Piech.
 **/

#include <fstream>
#include <iostream>
#include "console.h"   // required when using Stanford library
#include "stack.h"     // for Stack class
using namespace std;

// function prototype declarations
int checkBalance(string code);
void test(string s, int expected);

int main() {
    //    index
    //    0123456789012345678901234567890
    test("for (i=0;i<a(3};i++) { foo{); )", 14);
    test("while (true) foo(); }{ ()",       20);
    test("if (x) {",                         8);
    test("a{b(c)d(e(f)g{h}i)j}",            -1);
    test("if (x) }",                         7);
    test("if (xyz",                         7);
    return 0;
}

/*
 * Accepts a string of source code and checks whether the braces/parentheses
 * are balanced. Every ( or { must be closed by a } or ) in opposite order.
 * Returns the index at which an imbalance occurs, or -1 if balanced.
 * If any ( or { are never closed, returns the string's length.
 */
int checkBalance(string code) {

    Stack<char> parenStack;

    // loop over our string
    for(int i = 0; i < code.length(); i++) {

        char curr = code[i];

        // if curr is an open brace
        if(curr == '(' || curr == '{') {
            parenStack.push(curr);
        }

        // if curr is a close brace
        if(curr == ')' || curr == '}') {
            if(parenStack.isEmpty()) {
                return i;
            } else if(curr == ')' && parenStack.peek() != '(') {
                return i;
            } else if(curr == '}' && parenStack.peek() != '{') {
                return i;
            } else {
                parenStack.pop();
            }
        }

    }

    if(parenStack.isEmpty()) {
        return -1;
    }
    return code.length();
}


/*
 * Performs one test on the checkBalance function.
 * Prints the call's output and whether it matches what was expected.
 */
void test(string s, int expected) {
    int answer = checkBalance(s);
    cout << "checkBalance \"" << s << "\"  = " << answer;
    if (answer == expected) {
        cout << "  (PASS)" << endl;
    } else {
        cout << "  (FAIL!)" << endl;
    }
}
