import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * Class: Bottle
 * -------------
 * This is the interesting class. The one that actually hosts the server and
 * the functionality that I want recreated in a CS106 library.
 */
public class SimpleServer {

	// Port 8000 is a good call for security reasons.
	private static final int PORT = 8888;

	// This is the student application that can respond to calls
	private SimpleServerListener webApp;

	/**
	 * Method: Constructor
	 * -------------------
	 * All this method does is create an object that could be used to handle
	 * HTTP requests (but at the time of construction does nothing).
	 */
	public SimpleServer(SimpleServerListener webApp) {
		this.webApp = webApp;
	}

	/**
	 * Method: Start
	 * -------------
	 * This method starts a server on the given port. It is hard coded to handle
	 * img requests and resource requests specially by just reading the files and
	 * returning them. All other requests should be handled by the users code.
	 */
	public void start() {
		HttpServer server;
		try {
			server = HttpServer.create(new InetSocketAddress(PORT), 0);
			server.createContext("/", new SimpleHandler());
			server.setExecutor(null); // creates a default executor
			server.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method: Render Template
	 * -----------------------
	 * OPTIONAL: This method takes in a template (currently it takes the path to a template)
	 * and provides functionality for (a) importing other slivers of HTML and (b) inserting
	 * values from a map into all places in the template with the sequence {{key}}. See
	 * resources/index.html for an example.
	 */
	public static String renderTemplate(String templatePath, Map<String, String> args) {
		try {
			// This handles part (b)
			Scanner htmlScaller = new Scanner(new File(templatePath));
			String html = htmlScaller.useDelimiter("\\Z").next();
			htmlScaller.close();
			if(args != null) {
				for(String key : args.keySet()) {
					String value = args.get(key);
					html = html.replace("{{" + key + "}}" , value);
				}
			}

			// This handles inclues, part (a). Recursively applies render to included string
			String regex="\\%include\\[(.*)]";
			Pattern includePattern = Pattern.compile(regex);
			Matcher m = includePattern.matcher(html);
			String injectedHtml = html;
			while (m.find()) {
				String includePath = m.group(1);
				String injectHtml = renderTemplate(includePath, args);
				injectedHtml = injectedHtml.replace("%include[" + includePath + "]", injectHtml);    
			}
			return injectedHtml;
		} catch(FileNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	//=--------------- Private -------------=//


	/**
	 * Method: Get URI String
	 * -----------------------
	 * Gets the part of the http GET request after localhost:8000.
	 */
	private static String getUriString(HttpExchange exchange) {
		URI uri = exchange.getRequestURI();
		String uriStr = uri.toString();
		uriStr = uriStr.substring(1);
		return uriStr;
	}



	/**
	 * Class: BottleHandler
	 * -----------------------
	 * This class passes on an HTTP request to the "webApp" which the
	 * user writes.
	 */
	class SimpleHandler implements HttpHandler {
		@Override
		public void handle(HttpExchange t) throws IOException {
			// allow any source of input
			t.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
			t.getResponseHeaders().set("Content-Type", "text/plain");

			String uriStr = getUriString(t);
			System.out.println(uriStr);
			// call the students method
			String response = webApp.serverRequest(uriStr);
			// pass the response back to the caller
			t.sendResponseHeaders(200, response.length());


			OutputStream os = t.getResponseBody();
			os.write(response.getBytes());
			os.close();
		}
	}



	public static Map<String, String> splitQuery(String query) {
		int start = query.indexOf('?');
		query = query.substring(start + 1);
	    Map<String, String> query_pairs = new LinkedHashMap<String, String>();
	    String[] pairs = query.split("&");
	    for (String pair : pairs) {
	        int idx = pair.indexOf("=");
	        try {
				query_pairs.put(URLDecoder.decode(pair.substring(0, idx), "UTF-8"), URLDecoder.decode(pair.substring(idx + 1), "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				throw new RuntimeException(e);
			}
	    }
	    return query_pairs;
	}
}


