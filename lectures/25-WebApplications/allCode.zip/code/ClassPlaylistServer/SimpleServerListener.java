

public interface SimpleServerListener {

	String serverRequest(String uri);
	
}
