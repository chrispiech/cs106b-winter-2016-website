/*
 * File: FacePamphlet.java
 * --------------------
 * A demo of a different model for graphics in introduction programs.
 */

import java.util.ArrayList;
import java.util.Map;

public class ClassPlaylistServer implements SimpleServerListener {
	
	public static void main(String[] args) {
		new ClassPlaylistServer().run();
	}
	
	SimpleServer server = new SimpleServer(this);

	ArrayList<Song> songs = new ArrayList<Song>();
	
	public void run() {
		server.start();
		songs.add(new Song("All Right Now", "Free"));
		songs.add(new Song("Respect", "Aretha Franklin"));
		System.out.println("Starting server...");
	}

	// This gets called each time someone goes to the server from a web browser
	public String serverRequest(String uri) {
		if(uri.equals("getSongs")) {
			return getSongsRequest();
		}
		if(uri.startsWith("addSong")) {
			return addSongRequest(uri);
		}
		return "";
	}

	private String addSongRequest(String uri) {
		Map<String, String> params = SimpleServer.splitQuery(uri);
		String artist = params.get("artist");
		String songName = params.get("songName");
		if(artist == null || songName == null) {
			return "fail";
		}
		Song toAdd = new Song(songName, artist);
		songs.add(toAdd);
		return "success";
	}

	private String getSongsRequest() {
		String response = "[\n";
		for(int i = 0; i < songs.size(); i++){
			Song song = songs.get(i);
			response += song.getJson(1);
			if(i != songs.size() - 1) {
				response += ",";
			}
			response += "\n";
		}
		response += "]";
		return response;
	}

}
