
public class Song {
	public String songName;
	public String artist;
	
	public Song(String songName, String artist) {
		this.songName = songName;
		this.artist = artist;
	}

	public String getJson(int indent) {
		String json = indentStr(indent) + "{\n";
		json += indentStr(indent + 1) + "\"artist\" : \"" + artist + "\",\n";
		json += indentStr(indent + 1) + "\"songName\" : \"" + songName + "\"\n";
		json += indentStr(indent) + "}";
		return json;
	}

	private String indentStr(int indent) {
		String str = "";
		for(int i = 0; i < indent; i++) {
			str += "  ";
		}
		return str;
	}

}
