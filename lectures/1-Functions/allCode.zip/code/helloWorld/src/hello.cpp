/*
 * The canonical hello world program in C++
 */

#include <iostream>  // This is a true classic.
#include "console.h" // This is a Stanford Library!
using namespace std; // The best namespace.


int main() {

    cout << "mambo, dunia" << endl;

    return 0;
}




